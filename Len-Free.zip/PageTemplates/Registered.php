<?php
/*Template Name: Registered 【注册】*/
?>
<?php
wp_head();

wp_footer();
?>


