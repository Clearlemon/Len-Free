<?php
/*Template Name: Back password 【找回密码】*/
?>
<?php
wp_head();

wp_footer();
?>


