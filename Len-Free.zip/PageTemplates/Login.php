<?php
/*Template Name: Login 【登录】*/
?>
<?php
wp_head();

?>


<?php
wp_footer();
?>