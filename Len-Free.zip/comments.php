<?php

/**
 * 引用右侧边栏样式
 * require_once get_theme_file_path('/Page/Len-Block/Comments.php');
 * 评论模块样式文件目录
 */
require_once get_theme_file_path('/Page/Len-Block/Comments.php');
