<?php

/**
 * @About: Len主题顶部导航栏模块样式
 * @Author：青桔&dmy
 * @Url： https://github.com/Clearlemon/Len-Free
 * @Time：2024-1-4
 * @Email: Len@tqlen.com
 * @Project: Len主题
 * */
$Home_Module_3 = _len('Home_Module_3');
if ($Home_Module_3 == true) {
    Len_Nav_Module(true, false);
}
