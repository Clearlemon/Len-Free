<?php
var_dump($Len_Linked_Module_title);