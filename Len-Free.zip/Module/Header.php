<?php

function Len_Logo_Module()
{
  $Len_Logo_Module_2 = _len('Len_Logo_Module_2');

  return ' <div class="len-logo-fig"><img src="' . $Len_Logo_Module_2 . '" alt=""></div>';
}
